package com.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data // getter and setter
@AllArgsConstructor //args cons
@NoArgsConstructor //default cons
@ToString //tostring method
public class Users {
	
	private String uname;
	private String passwd;
	private String email;
	private String city;

}
