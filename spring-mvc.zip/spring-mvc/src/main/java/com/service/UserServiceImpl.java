package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Users;

@Service
public class UserServiceImpl implements UserService {
	
	List<Users> lst = new ArrayList<Users>();
	
	@Override
	public boolean loginCheck(Users users) {
		
		if(users.getUname().equals("admin") && users.getPasswd().equals("manager")) {
			return true;
		}
		return false;
		
	}
	
	@Override
	public void addUsers(Users users) {
		lst.add(users);
		System.out.println(lst);
		
	}
	
	@Override
	public List<Users> loadAll() {
		return lst;
		
	}
	
	@Override
	public boolean findUser(String uname) {
		for(Users user:lst) {
			if(user.getUname().equals(uname)) {
				System.out.println(user.getEmail());
				return true;
			}
		}
		return false;
		
	}
	
	@Override
	public void registerUser(Users users) {
		lst.add(users);
		
	}
	
	@Override
	public boolean deleteUser(String uname) {
		for(Users user:lst) {
			if(user.getUname().equals(uname)) {
				lst.remove(user);
				return true;
			}
		}
		return false;
		
	}
	
	@Override
	public void updateUser(String uname, Users users) {
		for(Users user:lst) {
			if(user.getUname().equals(uname)) {
				lst.remove(user);
				System.out.println("User updated....!");
			}
		}
		
	}

}
