package com.example.userserviceorm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceOrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
