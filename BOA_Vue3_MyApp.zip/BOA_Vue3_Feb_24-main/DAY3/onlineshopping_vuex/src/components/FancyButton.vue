<template>
    <button class="fancy-btn">
        <slot></slot> <!-- slot outlet -->
    </button>
</template>

<script setup>

</script>

<style  scoped></style>