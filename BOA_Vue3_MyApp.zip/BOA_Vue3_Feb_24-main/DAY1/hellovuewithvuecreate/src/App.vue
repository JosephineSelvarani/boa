<script setup>
import ListOfProducts from './components/ListOfProducts.vue';

</script>

<template>
  <ListOfProducts />
</template>

<style scoped></style>
