<script setup>

</script>

<template>
  <h1 class="read-the-docs">Hello Vue With Vite !</h1>
</template>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
