package com.example.springmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
