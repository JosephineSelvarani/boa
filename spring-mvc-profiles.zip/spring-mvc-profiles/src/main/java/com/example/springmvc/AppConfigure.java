package com.example.springmvc;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import lombok.Data;

@Configuration
@ConfigurationProperties("spring.datasource")
@Data
public class AppConfigure {
	
	private String url;
	private String username;
	private String password;
	
	@Bean
	@Profile("dev")
	public String loadDEVEnv() {
		System.out.println("Loading DEV Env....!");
		System.out.println(url);
		System.out.println(username);
		System.out.println(password);
		return "DEV Connected";
	}
	
	@Bean
	@Profile("prod")
	public String loadPRODEnv() {
		System.out.println("Loading PROD Env....!");
		System.out.println(url);
		System.out.println(username);
		System.out.println(password);
		return "PROD Connected";
	}
	
	@Bean
	@Profile("test")
	public String loadTESTEnv() {
		System.out.println("Loading TEST Env....!");
		System.out.println(url);
		System.out.println(username);
		System.out.println(password);
		return "TEST Connected";
	}
	
}
